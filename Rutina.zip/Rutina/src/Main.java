import cl.unab.ptec102.tarea2.core.Entrenamientos;
import cl.unab.ptec102.tarea2.gui.VentanaPrincipal;

void main() {
    // Instanciamos el backend primero
    Entrenamientos control = new Entrenamientos();
    
    // Le pasamos el backend a la ventana principal
    VentanaPrincipal menu = new VentanaPrincipal(control);
}