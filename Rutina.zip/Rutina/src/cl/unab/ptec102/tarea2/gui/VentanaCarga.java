package cl.unab.ptec102.tarea2.gui;

import cl.unab.ptec102.tarea2.core.Entrenamientos;
import javax.swing.*;
import java.awt.*;
import java.io.File;

public class VentanaCarga extends JFrame {

    private Entrenamientos backend;
    private JTextArea taInfo;
    private JButton btnBuscar;
    private JButton btnIrAGenerar;

    public VentanaCarga(Entrenamientos backend) {
        super("Cargar Ejercicios al Sistema");
        this.backend = backend;
        
        this.setSize(400, 450);
        this.setLocationRelativeTo(null); 
        // ojo: aca usamos DISPOSE_ON_CLOSE para que no se cierre todo el programa
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout(10, 10));

        btnBuscar = new JButton("Buscar archivo TXT o CSV...");
        taInfo = new JTextArea("Esperando cargar datos...\nSelecciona un archivo para continuar.");
        // para que el usuario no edite el texto
        taInfo.setEditable(false); 
        
        btnIrAGenerar = new JButton("Iniciar generación de rutina");
        btnIrAGenerar.setEnabled(false); 

        panel.add(btnBuscar, BorderLayout.NORTH);
        panel.add(new JScrollPane(taInfo), BorderLayout.CENTER);
        panel.add(btnIrAGenerar, BorderLayout.SOUTH);

        btnBuscar.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            // abrimos el explorador de archivos
            int resultado = chooser.showOpenDialog(this);
            
            if (resultado == JFileChooser.APPROVE_OPTION) {
                File archivoSeleccionado = chooser.getSelectedFile();
                try {
                    // Llamamos al backend para cargar los datos
                    backend.cargarArchivo(archivoSeleccionado.getAbsolutePath());
                    
                    String stats = "¡Archivo cargado con éxito!\n\n";
                    stats += "Total de ejercicios cargados: " + backend.getTotalEjercicios() + "\n";
                    stats += "Tiempo estimado total disponible: " + backend.getTiempoTotal() + " min\n\n";
                    
                    stats += "--- Cantidad por Tipo ---\n";
                    stats += "Cardiovascular: " + backend.getCantTipo("Cardiovascular") + "\n";
                    stats += "Fuerza: " + backend.getCantTipo("Fuerza") + "\n";
                    stats += "Equilibrio: " + backend.getCantTipo("Equilibrio") + "\n";
                    stats += "Resistencia: " + backend.getCantTipo("Resistencia") + "\n\n";
                    
                    stats += "--- Cantidad por Nivel ---\n";
                    stats += "Básico (1): " + backend.getCantNivel(1) + "\n";
                    stats += "Intermedio (2): " + backend.getCantNivel(2) + "\n";
                    stats += "Avanzado (3): " + backend.getCantNivel(3) + "\n";
                    stats += "Alto Rendimiento (4): " + backend.getCantNivel(4) + "\n";

                    taInfo.setText(stats);
                    
                    // habilitamos el boton para seguir
                    btnIrAGenerar.setEnabled(true);

                } catch (Exception ex) {
                    // Mostramos pop up en caso de error
                    JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Problema con el archivo", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        btnIrAGenerar.addActionListener(e -> {
            new VentanaGeneracionRutina(this.backend);
            this.dispose(); 
        });

        this.setContentPane(panel);
        this.setVisible(true);
    }
}