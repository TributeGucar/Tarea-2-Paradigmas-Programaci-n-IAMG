package cl.unab.ptec102.tarea2.gui;

import cl.unab.ptec102.tarea2.core.Ejercicio;
import javax.swing.*;
import java.awt.*;
import java.util.Vector;

public class VentanaRevisionRutina extends JFrame {
    
    private Vector<Ejercicio> rutina;
    private int posActual;
    private JTextArea taDetalle;
    private JButton btnVolver;
    private JButton btnSig;

    public VentanaRevisionRutina(Vector<Ejercicio> rutina) {
        super("Revisando Ejercicios");
        this.rutina = rutina;
        this.posActual = 0; // partimos en el primer elemento

        this.setSize(400, 300);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout());
        taDetalle = new JTextArea();
        taDetalle.setEditable(false);
        panel.add(new JScrollPane(taDetalle), BorderLayout.CENTER);

        JPanel btnPanel = new JPanel();
        btnVolver = new JButton("Volver");
        btnSig = new JButton("Siguiente");
        btnPanel.add(btnVolver);
        btnPanel.add(btnSig);
        panel.add(btnPanel, BorderLayout.SOUTH);

        // cargamos el primero al tiro
        actualizarVista();

        btnVolver.addActionListener(e -> {
            if (posActual > 0) {
                posActual--;
                actualizarVista();
            }
        });

        btnSig.addActionListener(e -> {
            if (posActual < rutina.size() - 1) {
                posActual++;
                actualizarVista();
            } else {
                // llegamos al ultimo, toca resumen
                new VentanaResumen(this.rutina);
                this.dispose();
            }
        });

        this.setContentPane(panel);
        this.setVisible(true);
    }

    private void actualizarVista() {
        Ejercicio current = rutina.get(posActual);
        
        String info = "Ejercicio " + (posActual + 1) + " de " + rutina.size() + "\n\n";
        info += "Nombre: " + current.getNombre() + "\n";
        info += "Tipo: " + current.getTipo() + "\n";
        info += "Nivel: " + current.getNivel() + "\n";
        info += "Tiempo: " + current.getMin() + " min\n";
        info += "Descripcion: " + current.getDescripcion() + "\n";
        
        taDetalle.setText(info);

        // apaga el boton volver si estamos en indice 0
        btnVolver.setEnabled(posActual > 0);

        // si llegamos al final cambia el texto
        if (posActual == rutina.size() - 1) {
            btnSig.setText("Resumen de la rutina");
        } else {
            btnSig.setText("Siguiente");
        }
    }
}