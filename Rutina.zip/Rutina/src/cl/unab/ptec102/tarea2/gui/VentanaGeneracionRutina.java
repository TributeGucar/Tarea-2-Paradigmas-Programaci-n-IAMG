package cl.unab.ptec102.tarea2.gui;

import cl.unab.ptec102.tarea2.core.Entrenamientos;
import cl.unab.ptec102.tarea2.core.Ejercicio;
import javax.swing.*;
import java.awt.*;
import java.util.Vector;

public class VentanaGeneracionRutina extends JFrame {
    
    private Entrenamientos backend;
    private JTextField tfCardio;
    private JTextField tfFuerza;
    private JComboBox<String> cbNivel;
    private JTextField tfSemana;
    private JButton btnGenerar;

    public VentanaGeneracionRutina(Entrenamientos backend) {
        super("Generar Rutina");
        this.backend = backend;
        
        this.setSize(350, 250);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // grid para ordenar los inputs facil
        JPanel mainPanel = new JPanel(new GridLayout(5, 2, 10, 10));

        mainPanel.add(new JLabel(" Cant. Cardio:"));
        tfCardio = new JTextField();
        mainPanel.add(tfCardio);

        mainPanel.add(new JLabel(" Cant. Fuerza:"));
        tfFuerza = new JTextField();
        mainPanel.add(tfFuerza);

        mainPanel.add(new JLabel(" Nivel:"));
        String[] niveles = {"1 - Basico", "2 - Intermedio", "3 - Avanzado", "4 - Alto Rend."};
        cbNivel = new JComboBox<>(niveles);
        mainPanel.add(cbNivel);

        mainPanel.add(new JLabel(" Semana actual:"));
        tfSemana = new JTextField();
        mainPanel.add(tfSemana);

        btnGenerar = new JButton("Crear rutina");
        mainPanel.add(new JLabel("")); 
        mainPanel.add(btnGenerar);

        btnGenerar.addActionListener(e -> {
            try {
                // sacamos los datos de los txt
                int cCardio = Integer.parseInt(tfCardio.getText());
                int cFuerza = Integer.parseInt(tfFuerza.getText());
                int lvl = cbNivel.getSelectedIndex() + 1;
                int week = Integer.parseInt(tfSemana.getText());

                // tratamos de armar la rutina con la logica del core
                Vector<Ejercicio> rutinaLista = this.backend.generarRutina(cCardio, cFuerza, lvl, week);
                
                // pasamos la rutina a la sgte ventana usando el nuevo nombre
                new VentanaRevisionRutina(rutinaLista);
                this.dispose(); // cerramos esta

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        this.setContentPane(mainPanel);
        this.setVisible(true);
    }
}