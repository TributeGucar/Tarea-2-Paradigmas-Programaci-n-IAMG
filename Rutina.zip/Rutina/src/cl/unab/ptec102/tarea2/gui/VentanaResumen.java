package cl.unab.ptec102.tarea2.gui;

import cl.unab.ptec102.tarea2.core.Ejercicio;
import javax.swing.*;
import java.awt.*;
import java.util.Vector;

public class VentanaResumen extends JFrame {

    public VentanaResumen(Vector<Ejercicio> rutina) {
        super("Resumen Final");
        this.setSize(300, 250);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        int tCardio = 0;
        int tFuerza = 0;
        float tiempoObj = 0;

        // iteramos el vector para sacar estadisticas rapidas
        for (Ejercicio ej : rutina) {
            tiempoObj += ej.getMin();
            if (ej.getTipo().equalsIgnoreCase("Cardiovascular")) {
                tCardio++;
            } else if (ej.getTipo().equalsIgnoreCase("Fuerza")) {
                tFuerza++;
            }
        }

        JTextArea taInfo = new JTextArea();
        taInfo.setEditable(false);
        
        String txt = "--- RUTINA FINALIZADA ---\n\n";
        txt += "Total Cardio: " + tCardio + "\n";
        txt += "Total Fuerza: " + tFuerza + "\n";
        txt += "Tiempo total estimado: " + tiempoObj + " min\n";
        
        taInfo.setText(txt);

        this.add(new JScrollPane(taInfo));
        this.setVisible(true);
    }
}