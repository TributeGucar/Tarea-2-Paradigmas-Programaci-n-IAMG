package cl.unab.ptec102.tarea2.gui;

import cl.unab.ptec102.tarea2.core.Entrenamientos;
import javax.swing.*;
import java.awt.*;

public class VentanaPrincipal extends JFrame {
    private Entrenamientos backend;

    // componentes de la pantalla
    private JButton btnCargar;
    private JButton btnGenerar;
    private JButton btnRevisar;
    private JLabel lblStatus;

    public VentanaPrincipal(Entrenamientos backend) {
        super("Menu Principal - Gestión de Rutinas");
        this.backend = backend;

        // Configuración básica de la pantalla
        this.setSize(400, 300);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 1, 10, 10));

        // Inicializamos los botones y el texto
        btnCargar = new JButton("1. Cargar Archivo de Ejercicios");
        btnGenerar = new JButton("2. Generar Nueva Rutina");
        btnRevisar = new JButton("3. Revisar Rutina Actual");
        lblStatus = new JLabel("Estado: Esperando archivo...", SwingConstants.CENTER);

        // Al principio desactivamos los botones de la rutina hasta que carguen el archivo
        btnGenerar.setEnabled(false);
        btnRevisar.setEnabled(false);

        // Metemos todo al panel
        panel.add(btnCargar);
        panel.add(btnGenerar);
        panel.add(btnRevisar);
        panel.add(lblStatus);

        btnCargar.addActionListener(e -> {
            VentanaCarga ventanaCarga = new VentanaCarga(this.backend); //se abre ventana y pasa a backend
            lblStatus.setText("Estado: Cargando archivo...");
        });

        btnGenerar.addActionListener(e -> {
            new VentanaGeneracionRutina(this.backend);
            lblStatus.setText("Estado: Armando nueva rutina...");
        });

        btnRevisar.addActionListener(e -> { // aquí abriremos la ventana para navegar por los ejercicios
            lblStatus.setText("Abriendo revisor de ejercicios...");
        });

        this.setContentPane(panel);
        this.setVisible(true);
    }
}