package cl.unab.ptec102.tarea2.core;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.util.Vector;

public class Entrenamientos {

    private Vector<Ejercicio> baseDatos;

    public Entrenamientos() {
        this.baseDatos = new Vector<>();
    }

    // metodo para cargar el archivo txt
    public void cargarArchivo(String nombreArchivo) throws Exception {
        try {
            BufferedReader br = new BufferedReader(new FileReader(nombreArchivo));
            String line = br.readLine();
            
            while (line != null) {
                String[] parts = line.split(";");
                
                // validacion de la info incompleta
                if (parts.length < 6) {
                    br.close();
                    throw new Exception("Faltan datos en una de las lineas del archivo.");
                }

                try {
                    int id = Integer.parseInt(parts[0].trim());
                    String name = parts[1].trim();
                    String type = parts[2].trim();
                    int lvl = Integer.parseInt(parts[3].trim());
                    float time = Float.parseFloat(parts[4].trim());
                    String desc = parts[5].trim();

                    Ejercicio nuevo = null;
                    if (type.equalsIgnoreCase("Cardiovascular")) {
                        nuevo = new Cardiovascular(id, name, lvl, time, desc);
                    } else if (type.equalsIgnoreCase("Fuerza")) {
                        nuevo = new Fuerza(id, name, lvl, time, desc);
                    } else if (type.equalsIgnoreCase("Equilibrio")) {
                        nuevo = new Equilibrio(id, name, lvl, time, desc);
                    } else if (type.equalsIgnoreCase("Resistencia")) {
                        nuevo = new Resistencia(id, name, lvl, time, desc);
                    } else {
                        br.close();
                        throw new Exception("Tipo de ejercicio invalido: " + type);
                    }

                    if (nuevo != null) {
                        this.baseDatos.add(nuevo);
                    }
                } catch (NumberFormatException e) {
                    br.close();
                    throw new Exception("Formato de numero incorrecto en el archivo.");
                }

                line = br.readLine();
            }
            br.close();
        } catch (FileNotFoundException e) {
            throw new Exception("El archivo no existe.");
        }
    }

    //logica para armar la rutina de la semana
    public Vector<Ejercicio> generarRutina(int conCardio, int conFuerza, int lvlDeseado, int weekActual) throws Exception {
        Vector<Ejercicio> nuevaRutina = new Vector<>();
        int countCardio = 0;
        int countFuerza = 0;

        for (Ejercicio e : baseDatos) {
            // se filtra por nivel y que no se repita de la semana anterior
            if (e.getNivel() == lvlDeseado && e.getUltimaSemana() != (weekActual - 1)) {
                
                if (e.getTipo().equalsIgnoreCase("Cardiovascular") && countCardio < conCardio) {
                    nuevaRutina.add(e);
                    e.setUltimaSemana(weekActual);
                    countCardio++;
                } else if (e.getTipo().equalsIgnoreCase("Fuerza") && countFuerza < conFuerza) {
                    nuevaRutina.add(e);
                    e.setUltimaSemana(weekActual);
                    countFuerza++;
                }
            }
        }

        // Validando si se logra juntar todo lo pedido
        if (countCardio < conCardio || countFuerza < conFuerza) {
            throw new Exception("No hay suficientes ejercicios cargados para armar la rutina.");
        }

        return nuevaRutina;
    }

    // Metodos cortitos para sacar las estadisticas que pide la ventana principal
    public int getTotalEjercicios() {
        return baseDatos.size();
    }

    public float getTiempoTotal() {
        float total = 0;
        for (Ejercicio e : baseDatos) {
            total += e.getMin();
        }
        return total;
    }

    public int getCantTipo(String tipo) {
        int c = 0;
        for (Ejercicio e : baseDatos) {
            if (e.getTipo().equalsIgnoreCase(tipo)) {
                c++;
            }
        }
        return c;
    }

    public int getCantNivel(int nivel) {
        int c = 0;
        for (Ejercicio e : baseDatos) {
            if (e.getNivel() == nivel) {
                c++;
            }
        }
        return c;
    }

    public Vector<Ejercicio> getBaseDatos() {
        return baseDatos;
    }
}