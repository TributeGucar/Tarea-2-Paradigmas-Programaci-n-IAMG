package cl.unab.ptec102.tarea2.core;

public class Ejercicio {
    private int id;
    private String nombre;
    private String tipo;
    private int nivel; 
    private float min; 
    private String descripcion;
    private int ultimaSemana; 

    public Ejercicio(int id, String nombre, String tipo, int nivel, float min, String descripcion) {
        this.id = id;
        this.nombre = nombre;
        this.tipo = tipo;
        this.nivel = nivel;
        this.min = min;
        this.descripcion = descripcion;
        this.ultimaSemana = -1; // -1 para saber que todavia no se usa en ninguna rutina
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public int getNivel() {
        return nivel;
    }

    public float getMin() {
        return min;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public int getUltimaSemana() {
        return ultimaSemana;
    }

    public void setUltimaSemana(int ultimaSemana) {
        this.ultimaSemana = ultimaSemana;
    }

    public String getDetalles(){
        return "ID: " + this.id + " | " + this.nombre + " [" + this.tipo + "] - Duracion: " + this.min + " min";
    }
}