package cl.unab.ptec102.tarea2.core;

public class Resistencia extends Ejercicio {

    public Resistencia(int id, String nombre, int nivel, float min, String descripcion) {
        // Le pasamos "Resistencia" fijo al constructor del padre
        super(id, nombre, "Resistencia", nivel, min, descripcion);
    }

    @Override
    public String getDetalles(){
        return "ID: " + this.getId() + " | " + this.getNombre() + " [Resistencia] | Descripcion: " + this.getDescripcion();
    }
}