package cl.unab.ptec102.tarea2.core;

public class Cardiovascular extends Ejercicio {

    public Cardiovascular(int id, String nombre, int nivel, float min, String descripcion) {
        // Le pasamos "Cardiovascular" directo al constructor del padre
        super(id, nombre, "Cardiovascular", nivel, min, descripcion);
    }

    @Override
    public String getDetalles(){
        return "ID: " + this.getId() + " | " + this.getNombre() + " [Cardio] | Descripcion: " + this.getDescripcion();
    }
}