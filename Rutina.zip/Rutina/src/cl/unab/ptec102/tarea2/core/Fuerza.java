package cl.unab.ptec102.tarea2.core;

public class Fuerza extends Ejercicio {

    public Fuerza(int id, String nombre, int nivel, float min, String descripcion) {
        super(id, nombre, "Fuerza", nivel, min, descripcion);
    }

    @Override
    public String getDetalles(){
        return "ID: " + this.getId() + " | " + this.getNombre() + " [Fuerza] | Descripcion: " + this.getDescripcion();
    }
}