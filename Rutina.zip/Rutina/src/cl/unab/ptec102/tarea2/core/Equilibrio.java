package cl.unab.ptec102.tarea2.core;

public class Equilibrio extends Ejercicio {

    public Equilibrio(int id, String nombre, int nivel, float min, String descripcion) {
        // Le pasamos "Equilibrio" fijo al constructor del padre
        super(id, nombre, "Equilibrio", nivel, min, descripcion);
    }

    @Override
    public String getDetalles(){
        return "ID: " + this.getId() + " | " + this.getNombre() + " [Equilibrio] | Descripcion: " + this.getDescripcion();
    }
}